from firedrake import *

from mkm import MKM

import numpy as np

import matplotlib.pyplot as plt
from matplotlib import rc
plt.rc('text', usetex=True)
plt.rc('font', size=14)

T = 473
P = 1e6

model = MKM('Test'+str(T), './rm_transport.mkm', 
            './g_transport.mkm', t_ref=T)

model.set_reactor('dynamic')
model.set_CSTR_params(radius=0.0025,
                      length=0.0050,
                      Q=0.66E-6,
                      S_BET=1.74E5,
                      m_cat=1.0E-4)

# Mesh definition
numel = 10
L = 20
x_left, x_right = 0.0, L
mesh = IntervalMesh(numel, x_left, x_right)
x = mesh.coordinates


# Function space declaration
degree = 3  # Polynomial degree of approximation
V = FunctionSpace(mesh, "CG", degree)
W = MixedFunctionSpace((V, V))
Vref = FunctionSpace(mesh, "CG", 1)

# Getting trial and test functions
w = Function(W)
u, v = split(w)
p,q = TestFunction(W)

# Initial conditions
w.dat.data[0][0] = 1.0

solver_parameters = {
    'mat_type': 'aij',
    'snes_tyoe': 'newtonls',
    'pc_type': 'lu'
}

w0 = Function(W)
u0, v0 = w0.split()
u0.interpolate(1 - (1. / 2.) * sin(pi * x[0] / L) ** 100.)
v0.interpolate((1. / 2.) * sin(pi * x[0] / L) ** 100.)


boundary_value_u = 1.0
boundary_value_v = 0.0
u_bc = DirichletBC(W.sub(0), boundary_value_u, [1, 2])  # Boundary condition in 1 and 2 marked bounds (left and right)
v_bc = DirichletBC(W.sub(1), boundary_value_v, [1, 2])  # Boundary condition in 1 and 2 marked bounds (left and right)

def solve_function(u,p, v, q):



    # ** U part **

    F =  inner(grad(u), grad(p)) * dx + inner(u-u0, p) *dx 
    # ** V part **
    
    F += inner(grad(v), grad(q)) * dx + inner(v-v0, q) *dx

    solve(F == 0, w, solver_parameters=solver_parameters)

    w0.assign(w)

    
    for ii,jj in zip(w.dat.data[0], w.dat.data[1]):
        if ii < 1e-5:
            
            ii = ii
            jj = jj
        else:
            if jj + ii != 1.0:
                ii = round(ii,2)
                jj = round(jj,2)
                x = model.kinetic_run(T, P, np.asarray([ii,jj]))
                ii = x["y_out"]["A(g)"]
                jj = x["y_out"]["B(g)"]
            else:
                ii = ii
                jj = jj
    
    


    usol, vsol = w.split()



    return usol,vsol

Total_time = 10.

# Iterating and solving over the time
step = 0
t = 0.0
dt = 1.0
x_values = mesh.coordinates.vector().dat.data
u_values = []
v_values = []
u_values_deg1 = []
v_values_deg1 = []
usol_deg1 = Function(Vref)
vsol_deg1 = Function(Vref)
while t < Total_time:
    step += 1
    print('============================')
    print('\ttime =', t)
    print('\tstep =', step)
    print('============================')

    # solve(F == 0, w, bcs=[u_bc, v_bc], solver_parameters=solver_parameters)
    #solve(F == 0, w, solver_parameters=solver_parameters)
    #w0.assign(w)
    usol, vsol = solve_function(u,p,v,q)

    usol_deg1.project(usol)
    vsol_deg1.project(vsol)
    u_vec = np.array(usol.vector().dat.data)
    u_values.append(u_vec)
    u_vec_deg1 = np.array(usol_deg1.vector().dat.data)
    u_values_deg1.append(u_vec_deg1)
    v_vec = np.array(vsol.vector().dat.data)
    v_values.append(v_vec)
    v_vec_deg1 = np.array(vsol_deg1.vector().dat.data)
    v_values_deg1.append(v_vec_deg1)

    t += dt

# Setting up the figure object


fig = plt.figure(dpi=300, figsize=(8, 6))
ax = plt.subplot(111)

# Plotting
ax.plot(x_values, u_values_deg1[step-1], '--', label='U')
ax.plot(x_values, v_values_deg1[step-1], label='V')

# Getting and setting the legend
box = ax.get_position()
ax.set_position([box.x0, box.y0, 1.05 * box.width, box.height])
ax.legend(loc='center left', bbox_to_anchor=(1, 0.5))

# Setting the xy-labels
plt.xlabel(r'$x$ [L]')
plt.ylabel(r'concentration [adim]')
plt.xlim(x_values.min(), x_values.max())

# Setting the grids in the figure
plt.minorticks_on()
plt.grid(True)
plt.grid(False, linestyle='--', linewidth=0.5, which='major')
plt.grid(False, linestyle='--', linewidth=0.1, which='minor')

plt.tight_layout()
plt.savefig('gray-scott.png')
# plt.show()

# Colormap
fig = plt.figure(dpi=300, figsize=(8, 6))
Vplot = np.array(v_values_deg1)
p = plt.imshow(Vplot, origin="lower", aspect='auto', cmap='jet')
clb = plt.colorbar(p)
plt.xlabel(r'x')
plt.ylabel(r't')
plt.savefig('gray-scott-pattern.png')
# plt.show()