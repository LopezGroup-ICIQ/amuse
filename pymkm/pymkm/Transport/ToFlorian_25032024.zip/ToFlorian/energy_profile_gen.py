"""
pymkm: module for generating automatically reaction energy profiles figures
"""

import mkm
import matplotlib.pyplot as plt

print("Hola")